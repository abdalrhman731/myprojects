document.querySelectorAll('.order-btn').forEach(button => {
  button.addEventListener('click', async () => {
      const menuItemName = button.getAttribute('data-name');
      const menuItemPrice = parseFloat(button.getAttribute('data-price'));

      try {
          const response = await fetch('http://localhost:3005/addMenuItem', {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json'
              },
              body: JSON.stringify({ name: menuItemName, price: menuItemPrice })
          });

          if (response.ok) {
              alert('Menu item added successfully.');
          } else {
              throw new Error('Failed to add menu item.');
          }
      } catch (error) {
          console.error(error);
          alert('Error adding menu item. Please try again.');
      }
  });
});
