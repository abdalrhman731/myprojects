document.getElementById('loginForm').addEventListener('submit', function(event) {
  event.preventDefault();

  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  
  if (!validateEmail(username)) {
      displayErrorMessage('Please enter a valid email address.');
      return;
  }

  if (!validatePassword(password)) {
      displayErrorMessage('Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, and one number.');
      return;
  }

  
  fetch('/page3', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ username: username, password: password })
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      alert('Login successful!');
      window.location.href = 'index.html';
    } else {
      displayErrorMessage(data.message || 'Login failed. Please try again.');
    }
  })
  .catch(error => {
    console.error('Error:', error);
    displayErrorMessage('An error occurred. Please try again.');
  });
});

function validateEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

function validatePassword(password) {
  const re = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/;
  return re.test(password);
}

function displayErrorMessage(message) {
  const errorMessageElement = document.getElementById('errorMessage');
  errorMessageElement.textContent = message;
}
