const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const User = require('./models/users'); 
const MenuItem=require('./models/menuItems');
const path = require('path');
const app = express();

app.use(express.static("views")); 
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.set('view engine', 'ejs');

const port = 3005;


const connectionString = "mongodb+srv://abdelrhmanmagdy731:pkdsm1MByLeJN9Ol@teaching.0norgxy.mongodb.net/Library?retryWrites=true&w=majority&appName=Teaching";

mongoose.connect(connectionString, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    app.listen(port, () => {
      console.log(`Server is running on port ${port}`);
    });
    console.log("Connected to MongoDB");
  })
  .catch((err) => {
    console.log("Failed to connect to MongoDB", err);
  });
  app.get("/index.html", (req, res) => {
    res.render("index");
  });
  app.get("/page2.html", (req, res) => {
    res.render("page2");
  });


app.get("/page3.html", (req, res) => {
  res.render("page3");
});

// Handle form submission
app.post("/page3", async (req, res) => {
    const { username, password } = req.body;
  
    if (!username || !password) {
      return res.status(400).json({ message: "Username and password are required" });
    }
  
    try {
      // Check if the username already exists in the database
      let existingUser = await User.findOne({ username });
  
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }
  
      // Create a new user document with the provided username and password
      const newUser = new User({ username, password });
      console.log(newUser);
  
      
      await newUser.save();
  
      
      res.status(200).json({ success: true, message: "User registration successful" });
    } catch (err) {
      
      console.error("Error while saving user:", err);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
// Handle adding menu items
app.post("/addMenuItem", async (req, res) => {
    const { name, price } = req.body;

    if (!name || !price) {
        return res.status(400).json({ message: "Menu item name and price are required" });
    }

    try {
        // Create a new menu item document
        const newMenuItem = new MenuItem({ name, price });

        // Save the new menu item to the database
        await newMenuItem.save();

        res.status(200).json({ message: "Menu item added successfully" });
    } catch (err) {
        console.error("Error while adding menu item:", err);
        res.status(500).json({ message: "Internal server error" });
    }
});

